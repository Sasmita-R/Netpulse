@echo off
title NetPulse - AI Network Monitoring & Anomaly Detection System
color 0B

echo ===============================================================================
echo                NETPULSE: AI NETWORK MONITORING SYSTEM
echo         Isolation Forest Anomaly Detection with Explainable AI (XAI)
echo                 Dataset: CIC-IDS2017 (Canadian Cybersec)
echo ===============================================================================
echo.

:: Check Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not found on your system PATH!
    echo Please install Python 3.9+ from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/3] Checking and installing Python dependencies...
python -m pip install -r requirements.txt --quiet

echo.
echo [2/3] Launching NetPulse FastAPI Backend Server...
echo Host: http://localhost:8000
echo.

:: Automatically open browser in background
start "" "http://localhost:8000"

echo [3/3] Server running on http://127.0.0.1:8000 (Press Ctrl+C to stop)
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
pause
