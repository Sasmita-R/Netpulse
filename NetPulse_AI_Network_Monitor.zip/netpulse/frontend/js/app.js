/**
 * NetPulse - Frontend Orchestration and Visualizations
 * Handles WebSocket telemetry, Chart.js live streams, Explainable AI (XAI),
 * Attack scenario injection, and CIC-IDS2017 benchmark evaluations.
 */

// Application State
const state = {
    ws: null,
    isStreaming: true,
    speed: 1.0,
    currentContext: "BUSINESS_HOURS",
    soundEnabled: true,
    flows: [],
    alerts: [],
    charts: {},
    maxChartPoints: 25,
    metrics: null
};

// Audio synthesized alert chime
const alertSound = {
    play: () => {
        if (!state.soundEnabled) return;
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = "sine";
            osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
            osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.18);
            gain.gain.setValueAtTime(0.12, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.18);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.2);
        } catch (e) {
            // Audio context policy fallback
        }
    }
};

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
    initTabs();
    initCharts();
    initWebSocket();
    initControls();
    fetchBenchmarkMetrics();
    fetchInitialStatus();
});

// ----------------- Tab Navigation -----------------
function initTabs() {
    const tabBtns = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            tabContents.forEach(c => c.classList.remove("active"));

            btn.classList.add("active");
            const targetId = btn.getAttribute("data-tab");
            const targetContent = document.getElementById(targetId);
            if (targetContent) {
                targetContent.classList.add("active");
            }

            // Trigger chart resize on tab switch
            Object.values(state.charts).forEach(chart => {
                if (chart && typeof chart.resize === "function") {
                    setTimeout(() => chart.resize(), 50);
                }
            });
        });
    });
}

// ----------------- Chart.js Visualizations -----------------
function initCharts() {
    // 1. Throughput & Packet Rate Live Timeline
    const ctxTraffic = document.getElementById("trafficStreamChart");
    if (ctxTraffic) {
        state.charts.traffic = new Chart(ctxTraffic, {
            type: "line",
            data: {
                labels: [],
                datasets: [
                    {
                        label: "Bandwidth (KB/s)",
                        data: [],
                        borderColor: "#00f2fe",
                        backgroundColor: "rgba(0, 242, 254, 0.08)",
                        borderWidth: 2,
                        fill: true,
                        tension: 0.35,
                        yAxisID: "y"
                    },
                    {
                        label: "Packet Rate (pkts/s)",
                        data: [],
                        borderColor: "#a855f7",
                        backgroundColor: "transparent",
                        borderWidth: 2,
                        borderDash: [4, 4],
                        tension: 0.35,
                        yAxisID: "y1"
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 300 },
                scales: {
                    x: {
                        grid: { color: "rgba(255, 255, 255, 0.04)" },
                        ticks: { color: "#64748b", font: { family: "JetBrains Mono", size: 10 } }
                    },
                    y: {
                        position: "left",
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#94a3b8", font: { size: 10 } },
                        title: { display: true, text: "KB/s", color: "#64748b" }
                    },
                    y1: {
                        position: "right",
                        grid: { drawOnChartArea: false },
                        ticks: { color: "#c084fc", font: { size: 10 } },
                        title: { display: true, text: "pkts/s", color: "#a855f7" }
                    }
                },
                plugins: {
                    legend: { labels: { color: "#cbd5e1", font: { family: "Outfit" } } }
                }
            }
        });
    }

    // 2. Anomaly Score & Dynamic Baseline Timeline
    const ctxAnomaly = document.getElementById("anomalyScoreChart");
    if (ctxAnomaly) {
        state.charts.anomaly = new Chart(ctxAnomaly, {
            type: "line",
            data: {
                labels: [],
                datasets: [
                    {
                        label: "Isolation Score",
                        data: [],
                        borderColor: "#38bdf8",
                        backgroundColor: "rgba(56, 189, 248, 0.12)",
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: "Adaptive Threshold",
                        data: [],
                        borderColor: "#f43f5e",
                        borderDash: [5, 5],
                        borderWidth: 2,
                        fill: false,
                        pointRadius: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 300 },
                scales: {
                    x: {
                        grid: { color: "rgba(255, 255, 255, 0.04)" },
                        ticks: { color: "#64748b", font: { family: "JetBrains Mono", size: 10 } }
                    },
                    y: {
                        min: 0,
                        max: 1.0,
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#94a3b8", font: { size: 10 } }
                    }
                },
                plugins: {
                    legend: { labels: { color: "#cbd5e1", font: { family: "Outfit" } } }
                }
            }
        });
    }

    // 3. XAI Feature Contribution Waterfall Chart
    const ctxWaterfall = document.getElementById("xaiWaterfallChart");
    if (ctxWaterfall) {
        state.charts.waterfall = new Chart(ctxWaterfall, {
            type: "bar",
            data: {
                labels: [],
                datasets: [{
                    label: "Contribution %",
                    data: [],
                    backgroundColor: [
                        "rgba(244, 63, 94, 0.85)",
                        "rgba(245, 158, 11, 0.85)",
                        "rgba(56, 189, 248, 0.85)",
                        "rgba(168, 85, 247, 0.85)",
                        "rgba(16, 185, 129, 0.85)"
                    ],
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: "y",
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        max: 100,
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#94a3b8", callback: v => `${v}%` }
                    },
                    y: {
                        grid: { color: "rgba(255, 255, 255, 0.03)" },
                        ticks: { color: "#f8fafc", font: { family: "Outfit", weight: "600" } }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    // 4. ROC Curve Chart
    const ctxRoc = document.getElementById("rocCurveChart");
    if (ctxRoc) {
        state.charts.roc = new Chart(ctxRoc, {
            type: "line",
            data: {
                datasets: [
                    {
                        label: "NetPulse Isolation Forest (AUC = 0.96)",
                        data: [],
                        borderColor: "#00f2fe",
                        backgroundColor: "rgba(0, 242, 254, 0.15)",
                        borderWidth: 2.5,
                        fill: true,
                        tension: 0.2
                    },
                    {
                        label: "Random Guess (Baseline)",
                        data: [{x: 0, y: 0}, {x: 1, y: 1}],
                        borderColor: "rgba(255, 255, 255, 0.2)",
                        borderDash: [4, 4],
                        borderWidth: 1.5,
                        pointRadius: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: "linear",
                        min: 0,
                        max: 1,
                        title: { display: true, text: "False Positive Rate (FPR)", color: "#94a3b8" },
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#64748b" }
                    },
                    y: {
                        type: "linear",
                        min: 0,
                        max: 1,
                        title: { display: true, text: "True Positive Rate (TPR / Recall)", color: "#94a3b8" },
                        grid: { color: "rgba(255, 255, 255, 0.05)" },
                        ticks: { color: "#64748b" }
                    }
                },
                plugins: {
                    legend: { labels: { color: "#cbd5e1" } }
                }
            }
        });
    }
}

// ----------------- WebSocket Live Telemetry -----------------
function initWebSocket() {
    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${location.host}/ws/traffic`;

    try {
        state.ws = new WebSocket(wsUrl);

        state.ws.onopen = () => {
            document.getElementById("connectionStatusBadge").innerHTML = `
                <span class="pulse-dot"></span>
                <span>MONITORING ACTIVE</span>
            `;
            document.getElementById("connectionStatusBadge").style.color = "var(--accent-emerald)";
        };

        state.ws.onmessage = (event) => {
            const msg = JSON.parse(event.data);

            if (msg.type === "flow_telemetry") {
                handleFlowTelemetry(msg.data, msg.stats);
            } else if (msg.type === "initial_state") {
                if (msg.recent_flows) {
                    msg.recent_flows.forEach(f => prependFlowRow(f, false));
                }
                if (msg.recent_alerts) {
                    msg.recent_alerts.forEach(a => prependAlertCard(a));
                }
            }
        };

        state.ws.onclose = () => {
            document.getElementById("connectionStatusBadge").innerHTML = `
                <span style="width:8px;height:8px;background:#ef4444;border-radius:50%;display:inline-block"></span>
                <span>RECONNECTING...</span>
            `;
            document.getElementById("connectionStatusBadge").style.color = "#f87171";
            setTimeout(initWebSocket, 2000);
        };

        state.ws.onerror = () => {
            state.ws.close();
        };
    } catch (e) {
        console.error("WS error:", e);
    }
}

function handleFlowTelemetry(flow, stats) {
    // 1. Update KPI Counters
    if (stats) {
        document.getElementById("kpiTotalFlows").textContent = stats.total_processed.toLocaleString();
        document.getElementById("kpiAnomalyCount").textContent = stats.total_anomalies.toLocaleString();
        document.getElementById("kpiAnomalyRate").textContent = `${stats.anomaly_rate}%`;
    }

    const kbps = (flow.flow_bytes_per_sec / 1024).toFixed(1);
    const pps = Math.round(flow.flow_packets_per_sec);
    document.getElementById("kpiThroughput").textContent = `${kbps} KB/s`;
    document.getElementById("kpiPacketRate").textContent = `${pps} pkts/s`;

    // 2. Stream Data to Live Charts
    const timeLabel = new Date(flow.timestamp * 1000).toLocaleTimeString([], { hour12: false, minute: '2-digit', second: '2-digit' });

    if (state.charts.traffic) {
        const d = state.charts.traffic.data;
        d.labels.push(timeLabel);
        d.datasets[0].data.push(parseFloat(kbps));
        d.datasets[1].data.push(pps);
        if (d.labels.length > state.maxChartPoints) {
            d.labels.shift();
            d.datasets[0].data.shift();
            d.datasets[1].data.shift();
        }
        state.charts.traffic.update("none");
    }

    if (state.charts.anomaly) {
        const d = state.charts.anomaly.data;
        d.labels.push(timeLabel);
        d.datasets[0].data.push(flow.adjusted_score);
        d.datasets[1].data.push(flow.adaptive_threshold);
        if (d.labels.length > state.maxChartPoints) {
            d.labels.shift();
            d.datasets[0].data.shift();
            d.datasets[1].data.shift();
        }
        state.charts.anomaly.update("none");
    }

    // 3. Prepend Row to Traffic Feed Table
    prependFlowRow(flow, true);

    // 4. Handle Alerts
    if (flow.is_anomaly) {
        alertSound.play();
        prependAlertCard(flow);
        flashAlertBanner(flow);
    }
}

function prependFlowRow(flow, animate = true) {
    const tbody = document.getElementById("liveFlowTableBody");
    if (!tbody) return;

    const row = document.createElement("tr");
    if (flow.is_anomaly) {
        row.classList.add("row-anomaly");
    }

    const badgeClass = flow.severity === "CRITICAL" ? "badge-critical" :
                       flow.severity === "HIGH" ? "badge-high" :
                       flow.severity === "MEDIUM" ? "badge-medium" : "badge-normal";

    const timeStr = new Date(flow.timestamp * 1000).toLocaleTimeString();

    row.innerHTML = `
        <td style="color:#64748b">${timeStr}</td>
        <td style="color:var(--accent-cyan);font-weight:600">${escapeHtml(flow.src_ip)}:${flow.src_port || '-'}</td>
        <td style="color:#cbd5e1">${escapeHtml(flow.dst_ip)}:${flow.dst_port || '-'}</td>
        <td><span style="color:#a855f7;font-weight:600">${flow.protocol}</span></td>
        <td>${(flow.flow_bytes_per_sec / 1024).toFixed(1)} KB/s</td>
        <td style="font-weight:700;color:${flow.is_anomaly ? '#f43f5e' : '#38bdf8'}">${(flow.adjusted_score * 100).toFixed(1)}%</td>
        <td><span class="badge ${badgeClass}">${flow.severity}</span></td>
        <td>
            <button class="btn btn-outline" style="padding:0.25rem 0.65rem;font-size:0.75rem;" onclick="openExplainModal('${flow.flow_id}')">
                🧠 Explain
            </button>
        </td>
    `;

    // Store in internal state
    state.flows.unshift(flow);
    if (state.flows.length > 200) state.flows.pop();

    tbody.insertBefore(row, tbody.firstChild);
    while (tbody.children.length > 50) {
        tbody.removeChild(tbody.lastChild);
    }
}

function prependAlertCard(flow) {
    const container = document.getElementById("recentAlertsContainer");
    if (!container) return;

    const card = document.createElement("div");
    card.style.cssText = "background:rgba(244,63,94,0.08);border:1px solid rgba(244,63,94,0.3);border-radius:var(--radius-md);padding:0.85rem 1rem;margin-bottom:0.75rem;cursor:pointer;transition:var(--transition-fast);";
    card.onmouseover = () => card.style.background = "rgba(244,63,94,0.15)";
    card.onmouseout = () => card.style.background = "rgba(244,63,94,0.08)";
    card.onclick = () => openExplainModal(flow.flow_id);

    const timeStr = new Date(flow.timestamp * 1000).toLocaleTimeString();
    const attackDesc = flow.explanation ? flow.explanation.attack_fingerprint : flow.attack_type;

    card.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.35rem">
            <span class="badge badge-critical">${flow.severity}</span>
            <small style="color:#94a3b8;font-family:var(--font-mono)">${timeStr}</small>
        </div>
        <div style="font-weight:700;font-size:0.88rem;color:#fda4af;margin-bottom:0.25rem">${escapeHtml(attackDesc)}</div>
        <div style="font-size:0.78rem;color:#cbd5e1;font-family:var(--font-mono)">
            ${escapeHtml(flow.src_ip)} ➔ ${escapeHtml(flow.dst_ip)}:${flow.dst_port}
        </div>
    `;

    state.alerts.unshift(flow);
    if (state.alerts.length > 50) state.alerts.pop();

    container.insertBefore(card, container.firstChild);
    while (container.children.length > 20) {
        container.removeChild(container.lastChild);
    }
}

function flashAlertBanner(flow) {
    const banner = document.getElementById("alertBannerBar");
    if (!banner) return;
    const text = document.getElementById("alertBannerText");
    if (text) {
        text.textContent = `ALERT: ${flow.explanation?.attack_fingerprint || flow.attack_type} detected from ${flow.src_ip} towards ${flow.dst_ip}:${flow.dst_port}`;
    }
    banner.style.display = "flex";
    setTimeout(() => {
        banner.style.display = "none";
    }, 4500);
}

// ----------------- Controls & Attack Simulator -----------------
function initControls() {
    // Play / Pause Stream
    const playPauseBtn = document.getElementById("btnPlayPause");
    if (playPauseBtn) {
        playPauseBtn.addEventListener("click", async () => {
            state.isStreaming = !state.isStreaming;
            playPauseBtn.textContent = state.isStreaming ? "⏸ Pause Stream" : "▶ Resume Stream";
            playPauseBtn.className = state.isStreaming ? "btn btn-outline" : "btn btn-primary";

            await fetch("/api/simulation/control", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: state.isStreaming ? "start" : "pause" })
            });
        });
    }

    // Speed Selector
    const speedSelect = document.getElementById("selectSpeed");
    if (speedSelect) {
        speedSelect.addEventListener("change", async (e) => {
            const speed = parseFloat(e.target.value);
            state.speed = speed;
            await fetch("/api/simulation/control", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "speed", speed: speed })
            });
        });
    }

    // Attack Scenario Injector
    const btnInject = document.getElementById("btnInjectAttack");
    const selectScenario = document.getElementById("selectAttackScenario");
    if (btnInject && selectScenario) {
        btnInject.addEventListener("click", async () => {
            const scenario = selectScenario.value;
            btnInject.textContent = "Injecting...";
            btnInject.disabled = true;

            try {
                await fetch("/api/simulation/inject", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ scenario: scenario, count: 12 })
                });
            } finally {
                setTimeout(() => {
                    btnInject.textContent = "⚡ Inject Scenario";
                    btnInject.disabled = false;
                }, 800);
            }
        });
    }

    // Traffic Source Selector (Dataset Replay vs Real PC Host IP)
    const selectSource = document.getElementById("selectTrafficSource");
    if (selectSource) {
        selectSource.addEventListener("change", async (e) => {
            const src = e.target.value;
            const res = await fetch("/api/source/set", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ source: src })
            });
            const data = await res.json();
            const hostIp = data.host_info ? data.host_info.local_ip : "192.168.1.8";
            if (src === "LIVE_HOST_INTERFACE") {
                alert(`[Live Adapter Active] NetPulse is now monitoring your machine's real IP address: ${hostIp}`);
            }
        });
    }

    // Context Selector
    const selectContext = document.getElementById("selectContextMode");
    if (selectContext) {
        selectContext.addEventListener("change", async (e) => {
            const ctx = e.target.value;
            state.currentContext = ctx;
            const res = await fetch("/api/context/set", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    context: ctx,
                    maintenance_mode: ctx === "MAINTENANCE_BACKUP"
                })
            });
            const data = await res.json();
            document.getElementById("contextDescriptionText").textContent = data.profile?.description || "";
        });
    }

    // Sound Toggle
    const soundBtn = document.getElementById("btnToggleSound");
    if (soundBtn) {
        soundBtn.addEventListener("click", () => {
            state.soundEnabled = !state.soundEnabled;
            soundBtn.textContent = state.soundEnabled ? "🔊 Sound: On" : "🔇 Sound: Off";
        });
    }

    // Custom Flow Simulator in XAI Inspector
    const btnSimCustom = document.getElementById("btnSimulateCustomFlow");
    if (btnSimCustom) {
        btnSimCustom.addEventListener("click", async () => {
            await simulateCustomXAI();
        });
    }

    // Model Retraining
    const btnRetrain = document.getElementById("btnRetrainModel");
    if (btnRetrain) {
        btnRetrain.addEventListener("click", async () => {
            const contam = parseFloat(document.getElementById("retrainContamination").value) || 0.15;
            const n_est = parseInt(document.getElementById("retrainEstimators").value) || 100;

            btnRetrain.textContent = "Retraining Isolation Forest...";
            btnRetrain.disabled = true;

            try {
                const res = await fetch("/api/model/retrain", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ n_estimators: n_est, contamination: contam })
                });
                const data = await res.json();
                fetchBenchmarkMetrics();
                alert(`Isolation Forest retrained successfully! Precision: ${data.metrics.precision}%, F1-Score: ${data.metrics.f1_score}%`);
            } finally {
                btnRetrain.textContent = "⚡ Retrain Isolation Forest";
                btnRetrain.disabled = false;
            }
        });
    }

    // Export Reports
    const btnExportPdf = document.getElementById("btnExportReport");
    if (btnExportPdf) {
        btnExportPdf.addEventListener("click", () => {
            window.print();
        });
    }

    const btnExportJson = document.getElementById("btnExportJson");
    if (btnExportJson) {
        btnExportJson.addEventListener("click", async () => {
            const res = await fetch("/api/export/report");
            const data = await res.json();
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `NetPulse_Report_${Date.now()}.json`;
            a.click();
        });
    }
}

// ----------------- Explainable AI (XAI) Modal & Inspector -----------------
async function openExplainModal(flowId) {
    const modal = document.getElementById("xaiModalOverlay");
    if (!modal) return;

    modal.classList.add("open");

    // Search local cache first
    let flow = state.flows.find(f => f.flow_id === flowId);
    let exp = flow ? flow.explanation : null;

    if (!exp) {
        try {
            const res = await fetch(`/api/explain/${flowId}`);
            if (res.ok) exp = await res.json();
        } catch (e) {
            console.error("Failed to fetch explanation:", e);
        }
    }

    if (exp) {
        renderExplanationDetails(exp, flow);
    }
}

function closeExplainModal() {
    const modal = document.getElementById("xaiModalOverlay");
    if (modal) modal.classList.remove("open");
}

function renderExplanationDetails(exp, flow) {
    document.getElementById("modalFlowId").textContent = exp.flow_id || flow?.flow_id || "FLOW-REF";
    document.getElementById("modalSeverityBadge").textContent = exp.severity;
    document.getElementById("modalSeverityBadge").className = `badge ${
        exp.severity === "CRITICAL" ? "badge-critical" :
        exp.severity === "HIGH" ? "badge-high" :
        exp.severity === "MEDIUM" ? "badge-medium" : "badge-normal"
    }`;

    document.getElementById("modalScoreGauge").textContent = `${(exp.anomaly_score * 100).toFixed(1)}%`;
    document.getElementById("modalAttackFingerprint").textContent = exp.attack_fingerprint;
    document.getElementById("modalDiagnosisText").textContent = exp.natural_language_diagnosis;

    // Render Waterfall Chart in Modal
    const topFeats = exp.top_contributing_features || [];
    if (state.charts.waterfall) {
        state.charts.waterfall.data.labels = topFeats.map(f => f.label);
        state.charts.waterfall.data.datasets[0].data = topFeats.map(f => f.contribution_pct);
        state.charts.waterfall.update();
    }

    // Render Feature Comparison Matrix Table
    const tableBody = document.getElementById("modalFeatureComparisonBody");
    if (tableBody) {
        tableBody.innerHTML = "";
        topFeats.forEach(f => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td style="font-weight:600;color:#f8fafc">${escapeHtml(f.label)}</td>
                <td style="color:var(--accent-cyan);font-family:var(--font-mono)">${f.observed_value} ${f.unit}</td>
                <td style="color:#94a3b8;font-family:var(--font-mono)">${f.baseline_mean} ${f.unit}</td>
                <td style="color:${f.direction === 'HIGH' ? '#f43f5e' : '#38bdf8'};font-weight:700">${f.delta_text}</td>
                <td style="color:#a855f7;font-weight:700">${f.contribution_pct}%</td>
            `;
            tableBody.appendChild(tr);
        });
    }

    // Render Actionable Mitigations
    const actionsList = document.getElementById("modalMitigationsList");
    if (actionsList) {
        actionsList.innerHTML = "";
        const actions = exp.recommended_actions || [
            "Monitor source IP traffic across core switches.",
            "Verify whether connection matches legitimate host role."
        ];
        actions.forEach((act, idx) => {
            const li = document.createElement("li");
            li.className = "mitigation-item";
            li.innerHTML = `
                <span class="mitigation-num">${idx + 1}</span>
                <span>${escapeHtml(act)}</span>
            `;
            actionsList.appendChild(li);
        });
    }
}

async function simulateCustomXAI() {
    const payload = {
        flow_duration_us: parseFloat(document.getElementById("simDuration").value) || 250000,
        total_fwd_packets: parseInt(document.getElementById("simFwdPkts").value) || 8,
        total_backward_packets: parseInt(document.getElementById("simBwdPkts").value) || 4,
        total_length_fwd_packets: parseFloat(document.getElementById("simFwdBytes").value) || 850,
        total_length_bwd_packets: parseFloat(document.getElementById("simBwdBytes").value) || 2400,
        flow_bytes_per_sec: parseFloat(document.getElementById("simBytesSec").value) || 35000,
        flow_packets_per_sec: parseFloat(document.getElementById("simPacketsSec").value) || 95,
        flow_iat_mean: parseFloat(document.getElementById("simIatMean").value) || 8500,
        flow_iat_std: parseFloat(document.getElementById("simIatStd").value) || 3500,
        fwd_packet_length_mean: parseFloat(document.getElementById("simFwdLen").value) || 105,
        bwd_packet_length_mean: parseFloat(document.getElementById("simBwdLen").value) || 600,
        syn_flag_count: parseInt(document.getElementById("simSynCount").value) || 1,
        rst_flag_count: parseInt(document.getElementById("simRstCount").value) || 0,
        ack_flag_count: 1,
        average_packet_size: 270.0,
        src_ip: document.getElementById("simSrcIp").value || "192.168.10.77",
        dst_ip: document.getElementById("simDstIp").value || "10.0.0.50",
        dst_port: parseInt(document.getElementById("simDstPort").value) || 80,
        protocol: "TCP"
    };

    const res = await fetch("/api/explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });
    const data = await res.json();
    renderExplanationDetails(data.explanation, payload);
    openExplainModal(data.analysis_id);
}

// ----------------- Benchmark & Evaluation Lab -----------------
async function fetchBenchmarkMetrics() {
    try {
        const res = await fetch("/api/metrics");
        if (!res.ok) return;
        const data = await res.json();
        state.metrics = data;

        const m = data.metrics;
        document.getElementById("metricAccuracy").textContent = `${m.accuracy}%`;
        document.getElementById("metricPrecision").textContent = `${m.precision}%`;
        document.getElementById("metricRecall").textContent = `${m.recall}%`;
        document.getElementById("metricF1").textContent = `${m.f1_score}%`;
        document.getElementById("metricFPR").textContent = `${m.false_positive_rate}%`;
        document.getElementById("metricLatency").textContent = `${m.avg_detection_latency_ms} ms`;
        document.getElementById("metricThroughput").textContent = `${m.throughput_flows_per_sec.toLocaleString()} flows/s`;

        // Update Header/KPI Latency
        document.getElementById("kpiLatencyVal").textContent = `${m.avg_detection_latency_ms} ms`;
        document.getElementById("kpiPrecisionVal").textContent = `${m.precision}%`;

        // Confusion Matrix
        const cm = data.confusion_matrix;
        document.getElementById("cmTP").textContent = cm.true_positives.toLocaleString();
        document.getElementById("cmFP").textContent = cm.false_positives.toLocaleString();
        document.getElementById("cmTN").textContent = cm.true_negatives.toLocaleString();
        document.getElementById("cmFN").textContent = cm.false_negatives.toLocaleString();

        // ROC Curve
        if (state.charts.roc && data.roc_curve) {
            const rocPoints = data.roc_curve.map(pt => ({ x: pt.fpr, y: pt.tpr }));
            state.charts.roc.data.datasets[0].data = rocPoints;
            state.charts.roc.update();
        }

        // Category Breakdown Table
        const catTable = document.getElementById("categoryBreakdownBody");
        if (catTable && data.category_breakdown) {
            catTable.innerHTML = "";
            data.category_breakdown.forEach(cat => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td style="font-weight:600;color:#f8fafc">${escapeHtml(cat.category)}</td>
                    <td style="color:#94a3b8">${cat.total_flows}</td>
                    <td style="color:var(--accent-cyan);font-weight:600">${cat.detected}</td>
                    <td>
                        <span class="badge ${cat.detection_rate_pct >= 90 ? 'badge-normal' : cat.detection_rate_pct >= 70 ? 'badge-medium' : 'badge-high'}">
                            ${cat.detection_rate_pct}%
                        </span>
                    </td>
                `;
                catTable.appendChild(tr);
            });
        }
    } catch (e) {
        console.error("Failed to fetch metrics:", e);
    }
}

async function fetchInitialStatus() {
    try {
        const res = await fetch("/api/status");
        if (!res.ok) return;
        const data = await res.json();
        if (data.context) {
            const selectContext = document.getElementById("selectContextMode");
            if (selectContext) selectContext.value = data.context;
        }
    } catch (e) {
        console.error("Status fetch failed:", e);
    }
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
