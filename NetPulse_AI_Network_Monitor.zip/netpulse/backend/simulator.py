"""
NetPulse - Live Network Traffic Streamer & Attack Scenario Simulator
Simulates real-time enterprise network telemetry modeled after CIC-IDS2017,
with live WebSocket broadcasting, playback controls, and attack injection.
"""

import asyncio
import time
import random
import numpy as np
from typing import Dict, Any, List, Optional, Callable

class TrafficSimulator:
    def __init__(self, sample_records: List[Dict[str, Any]], broadcast_callback: Optional[Callable] = None):
        self.sample_records = sample_records
        self.broadcast_callback = broadcast_callback
        self.is_running = False
        self.speed = 1.0  # multiplier: 1x, 2x, 5x, 10x
        self.sample_idx = 0
        self.injected_queue: List[Dict[str, Any]] = []
        self.flow_history: List[Dict[str, Any]] = []
        self.max_history = 500
        self.total_flows_processed = 0
        self.total_anomalies_detected = 0

    def start(self):
        self.is_running = True

    def pause(self):
        self.is_running = False

    def set_speed(self, speed: float):
        self.speed = max(0.2, min(20.0, speed))

    def inject_scenario(self, scenario_type: str, count: int = 15):
        """
        Injects a burst of specific attack or benchmark traffic flows.
        """
        print(f"[NetPulse Simulator] Injecting scenario: {scenario_type} ({count} flows)")
        scenario_type = scenario_type.upper()

        for i in range(count):
            flow_id = f"INJ-{scenario_type[:4]}-{int(time.time()*1000)%100000}-{i+1}"
            now_ts = time.time()

            if "DDOS" in scenario_type:
                fwd_pkts = random.randint(350, 950)
                dur_us = float(random.uniform(90000, 450000))
                bytes_total = fwd_pkts * random.uniform(950, 1450)
                dur_sec = dur_us / 1e6
                flow = {
                    "flow_id": flow_id,
                    "timestamp": now_ts,
                    "src_ip": f"172.16.0.{random.randint(2, 250)}",
                    "dst_ip": "192.168.10.50",
                    "src_port": random.randint(10240, 65000),
                    "dst_port": 80,
                    "protocol": "TCP",
                    "attack_type": "DDoS LOIC Flood",
                    "flow_duration_us": dur_us,
                    "total_fwd_packets": fwd_pkts,
                    "total_backward_packets": random.randint(0, 1),
                    "total_length_fwd_packets": bytes_total,
                    "total_length_bwd_packets": 64.0,
                    "flow_bytes_per_sec": bytes_total / dur_sec,
                    "flow_packets_per_sec": fwd_pkts / dur_sec,
                    "flow_iat_mean": float(random.uniform(15, 60)),
                    "flow_iat_std": float(random.uniform(5, 25)),
                    "fwd_packet_length_mean": 1150.0,
                    "bwd_packet_length_mean": 0.0,
                    "syn_flag_count": random.randint(1, 4),
                    "rst_flag_count": 0,
                    "ack_flag_count": random.randint(0, 5),
                    "average_packet_size": 1150.0
                }

            elif "PORTSCAN" in scenario_type:
                target_port = 20 + (i * 3) + random.randint(0, 2)
                dur_us = float(random.uniform(800, 9000))
                flow = {
                    "flow_id": flow_id,
                    "timestamp": now_ts,
                    "src_ip": "192.168.10.88",
                    "dst_ip": "192.168.10.15",
                    "src_port": 49152 + i,
                    "dst_port": target_port,
                    "protocol": "TCP",
                    "attack_type": "PortScan SYN Sweep",
                    "flow_duration_us": dur_us,
                    "total_fwd_packets": random.randint(2, 5),
                    "total_backward_packets": 0,
                    "total_length_fwd_packets": 120.0,
                    "total_length_bwd_packets": 0.0,
                    "flow_bytes_per_sec": float(random.uniform(25000, 75000)),
                    "flow_packets_per_sec": float(random.uniform(650, 1800)),
                    "flow_iat_mean": float(random.uniform(300, 1200)),
                    "flow_iat_std": float(random.uniform(100, 400)),
                    "fwd_packet_length_mean": 44.0,
                    "bwd_packet_length_mean": 0.0,
                    "syn_flag_count": random.randint(2, 5),
                    "rst_flag_count": 0,
                    "ack_flag_count": 0,
                    "average_packet_size": 44.0
                }

            elif "HULK" in scenario_type or "SLOW" in scenario_type:
                dur_us = float(random.uniform(40000000, 110000000))
                fwd_pkts = random.randint(8, 25)
                bwd_pkts = random.randint(2, 5)
                flow = {
                    "flow_id": flow_id,
                    "timestamp": now_ts,
                    "src_ip": "172.16.0.99",
                    "dst_ip": "192.168.10.50",
                    "src_port": random.randint(30000, 60000),
                    "dst_port": 80,
                    "protocol": "TCP",
                    "attack_type": "DoS Slowloris / Hulk",
                    "flow_duration_us": dur_us,
                    "total_fwd_packets": fwd_pkts,
                    "total_backward_packets": bwd_pkts,
                    "total_length_fwd_packets": float(fwd_pkts * 52),
                    "total_length_bwd_packets": float(bwd_pkts * 64),
                    "flow_bytes_per_sec": float(random.uniform(12, 85)),
                    "flow_packets_per_sec": float(random.uniform(0.15, 0.9)),
                    "flow_iat_mean": float(random.uniform(3000000, 7000000)),
                    "flow_iat_std": float(random.uniform(800000, 2000000)),
                    "fwd_packet_length_mean": 52.0,
                    "bwd_packet_length_mean": 64.0,
                    "syn_flag_count": 1,
                    "rst_flag_count": 0,
                    "ack_flag_count": 3,
                    "average_packet_size": 56.0
                }

            elif "BRUTE" in scenario_type or "PATATOR" in scenario_type:
                fwd_pkts = random.randint(45, 95)
                bwd_pkts = random.randint(40, 85)
                dur_us = float(random.uniform(600000, 1500000))
                flow = {
                    "flow_id": flow_id,
                    "timestamp": now_ts,
                    "src_ip": "172.16.0.42",
                    "dst_ip": "192.168.10.22",
                    "src_port": random.randint(40000, 60000),
                    "dst_port": 22,
                    "protocol": "TCP",
                    "attack_type": "SSH Brute Force",
                    "flow_duration_us": dur_us,
                    "total_fwd_packets": fwd_pkts,
                    "total_backward_packets": bwd_pkts,
                    "total_length_fwd_packets": float(fwd_pkts * 96),
                    "total_length_bwd_packets": float(bwd_pkts * 112),
                    "flow_bytes_per_sec": float(random.uniform(35000, 95000)),
                    "flow_packets_per_sec": float(random.uniform(90, 240)),
                    "flow_iat_mean": float(random.uniform(18000, 36000)),
                    "flow_iat_std": float(random.uniform(9000, 18000)),
                    "fwd_packet_length_mean": 96.0,
                    "bwd_packet_length_mean": 112.0,
                    "syn_flag_count": 1,
                    "rst_flag_count": 2,
                    "ack_flag_count": 35,
                    "average_packet_size": 104.0
                }

            else:  # BENIGN SURGE (e.g. Backup / Cloud sync)
                fwd_pkts = random.randint(180, 420)
                bwd_pkts = random.randint(160, 390)
                dur_us = float(random.uniform(1200000, 3500000))
                tot_bytes = (fwd_pkts + bwd_pkts) * random.uniform(1100, 1400)
                dur_sec = dur_us / 1e6
                flow = {
                    "flow_id": flow_id,
                    "timestamp": now_ts,
                    "src_ip": "192.168.10.100",
                    "dst_ip": "192.168.10.200",
                    "src_port": random.randint(20000, 50000),
                    "dst_port": 443,
                    "protocol": "TCP",
                    "attack_type": "Benign Backup Surge",
                    "flow_duration_us": dur_us,
                    "total_fwd_packets": fwd_pkts,
                    "total_backward_packets": bwd_pkts,
                    "total_length_fwd_packets": tot_bytes * 0.5,
                    "total_length_bwd_packets": tot_bytes * 0.5,
                    "flow_bytes_per_sec": tot_bytes / dur_sec,
                    "flow_packets_per_sec": (fwd_pkts + bwd_pkts) / dur_sec,
                    "flow_iat_mean": float(random.uniform(1200, 4500)),
                    "flow_iat_std": float(random.uniform(400, 1500)),
                    "fwd_packet_length_mean": 1250.0,
                    "bwd_packet_length_mean": 1250.0,
                    "syn_flag_count": 1,
                    "rst_flag_count": 0,
                    "ack_flag_count": 120,
                    "average_packet_size": 1250.0
                }

            self.injected_queue.append(flow)

    def get_next_flow(self) -> Dict[str, Any]:
        """
        Retrieves the next flow either from injected queue or sample corpus.
        """
        now_ts = time.time()

        if self.injected_queue:
            flow = self.injected_queue.pop(0)
            flow["timestamp"] = now_ts
            return flow

        if not self.sample_records:
            # Fallback generation
            return {
                "flow_id": f"FLOW-{int(now_ts * 1000) % 100000}",
                "timestamp": now_ts,
                "src_ip": "192.168.1.15",
                "dst_ip": "142.250.190.46",
                "src_port": random.randint(32768, 61000),
                "dst_port": 443,
                "protocol": "TCP",
                "attack_type": "Benign Normal",
                "flow_duration_us": 120000.0,
                "total_fwd_packets": 6,
                "total_backward_packets": 7,
                "total_length_fwd_packets": 720.0,
                "total_length_bwd_packets": 4800.0,
                "flow_bytes_per_sec": 46000.0,
                "flow_packets_per_sec": 108.0,
                "flow_iat_mean": 9200.0,
                "flow_iat_std": 4100.0,
                "fwd_packet_length_mean": 120.0,
                "bwd_packet_length_mean": 685.0,
                "syn_flag_count": 1,
                "rst_flag_count": 0,
                "ack_flag_count": 1,
                "average_packet_size": 424.0
            }

        flow = dict(self.sample_records[self.sample_idx])
        self.sample_idx = (self.sample_idx + 1) % len(self.sample_records)
        flow["timestamp"] = now_ts
        # Small jitter to make it realistic
        flow["flow_id"] = f"FLOW-{self.total_flows_processed + 1}"
        return flow

    def record_processed_flow(self, flow: Dict[str, Any], is_anomaly: bool):
        self.total_flows_processed += 1
        if is_anomaly:
            self.total_anomalies_detected += 1

        self.flow_history.append(flow)
        if len(self.flow_history) > self.max_history:
            self.flow_history.pop(0)
