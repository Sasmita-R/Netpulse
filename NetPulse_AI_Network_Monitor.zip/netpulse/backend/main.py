"""
NetPulse - AI-Powered Network Monitoring and Anomaly Detection System
FastAPI Backend Server with WebSocket Streaming, Isolation Forest Inference,
Context-Aware Adaptive Baseline, and Explainable AI (XAI).
"""

import os
import sys
import time
import json
import asyncio
import numpy as np
from typing import Dict, Any, List, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Import NetPulse modules
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_DIR, "data")
MODEL_DIR = os.path.join(PROJECT_DIR, "models")
FRONTEND_DIR = os.path.join(PROJECT_DIR, "frontend")

sys.path.insert(0, PROJECT_DIR)

from backend.data_loader import CICIDS2017Loader, FEATURE_COLUMNS
from backend.ml.isolation_forest import NetPulseIsolationForest
from backend.ml.baseline_engine import AdaptiveBaselineEngine
from backend.ml.explainer import NetPulseXAIExplainer
from backend.ml.evaluator import ModelEvaluator
from backend.simulator import TrafficSimulator
from backend.live_sniffer import LiveInterfaceSniffer

# Global application state
state = {
    "data_loader": None,
    "model": None,
    "baseline_engine": None,
    "explainer": None,
    "simulator": None,
    "live_sniffer": None,
    "traffic_source": "CICIDS2017_DATASET", # or "LIVE_HOST_INTERFACE"
    "eval_results": None,
    "recent_flows": [],
    "recent_alerts": [],
    "active_connections": set(),
    "max_stored_flows": 1000,
    "start_time": time.time()
}

MODEL_PATH = os.path.join(MODEL_DIR, "isolation_forest_model.json")

def initialize_system():
    print("[NetPulse] Initializing system and training Isolation Forest on CIC-IDS2017...")
    loader = CICIDS2017Loader(DATA_DIR)
    state["data_loader"] = loader

    # Ensure dataset exists and load
    X, y, metadata = loader.load_dataset()
    print(f"[NetPulse] Loaded {len(X)} network flow records from CIC-IDS2017.")

    # Train / Load Isolation Forest
    model = NetPulseIsolationForest(n_estimators=100, max_samples=256, contamination=0.15)
    model.fit(X, feature_names=FEATURE_COLUMNS)
    if np.sum(y == 1) > 0:
        opt_thresh, opt_f1 = model.calibrate_with_labels(X, y)
        print(f"[NetPulse] Calibrated optimal decision threshold: {opt_thresh:.4f} (F1: {opt_f1*100:.1f}%)")
    model.save(MODEL_PATH)
    state["model"] = model
    print("[NetPulse] Isolation Forest successfully trained and persisted.")

    # Initialize Baseline & XAI
    state["baseline_engine"] = AdaptiveBaselineEngine(alpha=0.05, sensitivity=2.4)
    state["explainer"] = NetPulseXAIExplainer()

    # Pre-calculate Benchmark Metrics
    t_start = time.perf_counter()
    y_pred = model.predict(X)
    t_end = time.perf_counter()
    latencies = [(t_end - t_start) * 1000.0 / len(X)] * len(X)
    scores = model.score_samples(X)

    eval_results = ModelEvaluator.evaluate(y, y_pred, scores, latencies, metadata)
    state["eval_results"] = eval_results
    print(f"[NetPulse] Benchmark evaluated: F1-Score={eval_results['metrics']['f1_score']}%, Precision={eval_results['metrics']['precision']}%, Latency={eval_results['metrics']['avg_detection_latency_ms']}ms")

    # Combine X and metadata for simulator records
    sim_records = []
    for i, meta in enumerate(metadata):
        rec = dict(meta)
        for j, col in enumerate(FEATURE_COLUMNS):
            rec[col] = float(X[i][j])
        sim_records.append(rec)

    state["live_sniffer"] = LiveInterfaceSniffer()
    state["simulator"] = TrafficSimulator(sim_records)
    state["simulator"].start()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    initialize_system()
    asyncio.create_task(traffic_stream_worker())
    yield
    # Shutdown
    if state["simulator"]:
        state["simulator"].pause()

app = FastAPI(
    title="NetPulse: AI-Powered Network Monitoring & Anomaly Detection",
    description="Real-Time Network Monitoring with Isolation Forest and Explainable AI (XAI) on CIC-IDS2017.",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def traffic_stream_worker():
    """
    Background worker that continuously processes flows and streams
    telemetry to connected WebSockets.
    """
    while True:
        try:
            sim = state.get("simulator")
            model = state.get("model")
            baseline = state.get("baseline_engine")
            explainer = state.get("explainer")
            sniffer = state.get("live_sniffer")

            if sim and sim.is_running and model and baseline and explainer:
                if state.get("traffic_source") == "LIVE_HOST_INTERFACE" and sniffer:
                    flow = sniffer.capture_next_flow() or sim.get_next_flow()
                else:
                    flow = sim.get_next_flow()

                # Feature vector extraction
                feat_vec = np.array([float(flow.get(col, 0.0)) for col in FEATURE_COLUMNS])

                # Inference timing
                t0 = time.perf_counter()
                raw_score, _ = model.score_sample(feat_vec)
                inference_time_ms = (time.perf_counter() - t0) * 1000.0

                # Adaptive Baseline & Context Evaluation
                context_eval = baseline.evaluate_with_context(raw_score, flow)

                is_anomaly = context_eval["is_anomaly"]
                sim.record_processed_flow(flow, is_anomaly)

                # Process XAI explanation
                raw_exp = model.explain(feat_vec, top_k=4)
                full_exp = explainer.generate_explanation(flow, raw_exp, context_eval)

                # Store enriched flow record
                enriched_record = {
                    "flow_id": flow.get("flow_id"),
                    "timestamp": flow.get("timestamp", time.time()),
                    "src_ip": flow.get("src_ip"),
                    "dst_ip": flow.get("dst_ip"),
                    "src_port": flow.get("src_port"),
                    "dst_port": flow.get("dst_port"),
                    "protocol": flow.get("protocol"),
                    "attack_type": flow.get("attack_type", "Benign"),
                    "flow_bytes_per_sec": flow.get("flow_bytes_per_sec", 0.0),
                    "flow_packets_per_sec": flow.get("flow_packets_per_sec", 0.0),
                    "raw_score": round(raw_score, 4),
                    "adjusted_score": context_eval["adjusted_score"],
                    "adaptive_threshold": context_eval["adaptive_threshold"],
                    "is_anomaly": is_anomaly,
                    "severity": context_eval["severity"],
                    "behavioral_type": context_eval["behavioral_type"],
                    "inference_time_ms": round(inference_time_ms, 3),
                    "explanation": full_exp
                }

                # Maintain recent buffer
                state["recent_flows"].append(enriched_record)
                if len(state["recent_flows"]) > state["max_stored_flows"]:
                    state["recent_flows"].pop(0)

                if is_anomaly:
                    state["recent_alerts"].append(enriched_record)
                    if len(state["recent_alerts"]) > 200:
                        state["recent_alerts"].pop(0)

                # Broadcast to WebSockets
                if state["active_connections"]:
                    msg_payload = json.dumps({
                        "type": "flow_telemetry",
                        "data": enriched_record,
                        "stats": {
                            "total_processed": sim.total_flows_processed,
                            "total_anomalies": sim.total_anomalies_detected,
                            "anomaly_rate": round((sim.total_anomalies_detected / max(sim.total_flows_processed, 1)) * 100, 2),
                            "current_context": baseline.get_current_context()
                        }
                    })
                    # Send to all connected clients
                    dead_sockets = set()
                    for ws in state["active_connections"]:
                        try:
                            await ws.send_text(msg_payload)
                        except Exception:
                            dead_sockets.add(ws)
                    for ws in dead_sockets:
                        state["active_connections"].discard(ws)

            # Control stream delay based on simulator speed
            speed = sim.speed if sim else 1.0
            delay = max(0.05, 0.5 / speed)
            await asyncio.sleep(delay)

        except Exception as e:
            print(f"[NetPulse Stream Error] {e}")
            await asyncio.sleep(1.0)

# ----------------- WebSocket Endpoint -----------------
@app.websocket("/ws/traffic")
async def websocket_traffic_endpoint(websocket: WebSocket):
    await websocket.accept()
    state["active_connections"].add(websocket)
    try:
        # Send initial sync payload
        init_payload = {
            "type": "initial_state",
            "recent_flows": state["recent_flows"][-30:],
            "recent_alerts": state["recent_alerts"][-20:],
            "context": state["baseline_engine"].get_current_context(),
            "metrics": state["eval_results"]["metrics"] if state["eval_results"] else {}
        }
        await websocket.send_text(json.dumps(init_payload))

        while True:
            # Keep socket alive and receive client commands
            data = await websocket.receive_text()
            cmd = json.loads(data)
            if cmd.get("action") == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        state["active_connections"].discard(websocket)
    except Exception:
        state["active_connections"].discard(websocket)

# ----------------- REST API Endpoints -----------------
@app.get("/api/status")
def get_system_status():
    sim = state["simulator"]
    baseline = state["baseline_engine"]
    sniffer = state["live_sniffer"]
    uptime = time.time() - state["start_time"]

    return {
        "status": "ONLINE",
        "system_name": "NetPulse AI Network Monitoring",
        "uptime_seconds": int(uptime),
        "traffic_source": state["traffic_source"],
        "host_info": sniffer.get_host_info() if sniffer else None,
        "dataset": "CIC-IDS2017 (Canadian Institute for Cybersecurity)",
        "model": "NetPulse Isolation Forest (Vectorized Tree Path)",
        "context": baseline.get_current_context(),
        "simulator": {
            "is_running": sim.is_running if sim else False,
            "speed": sim.speed if sim else 1.0,
            "total_flows": sim.total_flows_processed if sim else 0,
            "total_anomalies": sim.total_anomalies_detected if sim else 0,
            "anomaly_rate_pct": round((sim.total_anomalies_detected / max(sim.total_flows_processed, 1)) * 100, 2) if sim else 0.0
        },
        "baselines": {k: round(v["mean"], 2) for k, v in baseline.baselines.items()}
    }

class TrafficSourceRequest(BaseModel):
    source: str # "CICIDS2017_DATASET" or "LIVE_HOST_INTERFACE"

@app.post("/api/source/set")
def set_traffic_source(req: TrafficSourceRequest):
    if req.source in ["CICIDS2017_DATASET", "LIVE_HOST_INTERFACE"]:
        state["traffic_source"] = req.source
    sniffer = state["live_sniffer"]
    return {
        "status": "updated",
        "traffic_source": state["traffic_source"],
        "host_info": sniffer.get_host_info() if sniffer else None
    }

@app.get("/api/metrics")
def get_evaluation_metrics():
    if not state["eval_results"]:
        raise HTTPException(status_code=503, detail="Evaluation metrics not ready yet.")
    return state["eval_results"]

@app.get("/api/alerts")
def get_recent_alerts(limit: int = 50, severity: Optional[str] = None):
    alerts = state["recent_alerts"]
    if severity:
        alerts = [a for a in alerts if a["severity"].upper() == severity.upper()]
    return list(reversed(alerts[-limit:]))

@app.get("/api/flows")
def get_recent_flows(limit: int = 100, anomalies_only: bool = False):
    flows = state["recent_flows"]
    if anomalies_only:
        flows = [f for f in flows if f["is_anomaly"]]
    return list(reversed(flows[-limit:]))

@app.get("/api/explain/{flow_id}")
def get_flow_explanation(flow_id: str):
    for f in reversed(state["recent_flows"]):
        if f.get("flow_id") == flow_id:
            return f["explanation"]
    raise HTTPException(status_code=404, detail=f"Flow {flow_id} not found in active telemetry buffer.")

class CustomExplainRequest(BaseModel):
    flow_duration_us: float = 150000.0
    total_fwd_packets: int = 8
    total_backward_packets: int = 6
    total_length_fwd_packets: float = 800.0
    total_length_bwd_packets: float = 3500.0
    flow_bytes_per_sec: float = 28666.0
    flow_packets_per_sec: float = 93.3
    flow_iat_mean: float = 10700.0
    flow_iat_std: float = 5200.0
    fwd_packet_length_mean: float = 100.0
    bwd_packet_length_mean: float = 583.3
    syn_flag_count: int = 1
    rst_flag_count: int = 0
    ack_flag_count: int = 1
    average_packet_size: float = 307.0
    src_ip: str = "192.168.1.105"
    dst_ip: str = "10.0.0.1"
    dst_port: int = 80
    protocol: str = "TCP"

@app.post("/api/explain")
def explain_custom_flow(req: CustomExplainRequest):
    model = state["model"]
    baseline = state["baseline_engine"]
    explainer = state["explainer"]

    flow_dict = req.model_dump()
    flow_dict["flow_id"] = f"ANALYSIS-{int(time.time()*1000)%100000}"
    feat_vec = np.array([float(flow_dict[col]) for col in FEATURE_COLUMNS])

    raw_score, _ = model.score_sample(feat_vec)
    context_eval = baseline.evaluate_with_context(raw_score, flow_dict)
    raw_exp = model.explain(feat_vec, top_k=6)
    full_exp = explainer.generate_explanation(flow_dict, raw_exp, context_eval)

    return {
        "analysis_id": flow_dict["flow_id"],
        "raw_score": round(raw_score, 4),
        "adjusted_score": context_eval["adjusted_score"],
        "adaptive_threshold": context_eval["adaptive_threshold"],
        "is_anomaly": context_eval["is_anomaly"],
        "severity": context_eval["severity"],
        "explanation": full_exp
    }

class ControlRequest(BaseModel):
    action: str  # "start", "pause", "speed"
    speed: Optional[float] = 1.0

@app.post("/api/simulation/control")
def control_simulation(req: ControlRequest):
    sim = state["simulator"]
    if req.action == "start":
        sim.start()
    elif req.action == "pause":
        sim.pause()
    elif req.action == "speed" and req.speed:
        sim.set_speed(req.speed)
    return {"is_running": sim.is_running, "speed": sim.speed}

class InjectRequest(BaseModel):
    scenario: str  # "DDOS", "PORTSCAN", "HULK", "BRUTE_FORCE", "BENIGN_SURGE"
    count: Optional[int] = 15

@app.post("/api/simulation/inject")
def inject_attack_scenario(req: InjectRequest):
    sim = state["simulator"]
    sim.inject_scenario(req.scenario, req.count or 15)
    return {"status": "injected", "scenario": req.scenario, "count": req.count or 15}

class ContextRequest(BaseModel):
    context: str  # "BUSINESS_HOURS", "EVENING", "OFF_HOURS", "MAINTENANCE_BACKUP"
    maintenance_mode: Optional[bool] = False

@app.post("/api/context/set")
def set_context_mode(req: ContextRequest):
    baseline = state["baseline_engine"]
    baseline.set_manual_context(req.context, req.maintenance_mode or False)
    return {
        "context": baseline.get_current_context(),
        "maintenance_mode": baseline.maintenance_mode,
        "profile": baseline.context_profiles.get(baseline.get_current_context())
    }

class RetrainRequest(BaseModel):
    n_estimators: int = 100
    contamination: float = 0.15

@app.post("/api/model/retrain")
def retrain_model(req: RetrainRequest):
    loader = state["data_loader"]
    X, y, metadata = loader.load_dataset()

    model = NetPulseIsolationForest(
        n_estimators=req.n_estimators,
        max_samples=256,
        contamination=req.contamination
    )
    model.fit(X, feature_names=FEATURE_COLUMNS)
    model.save(MODEL_PATH)
    state["model"] = model

    # Re-evaluate
    t0 = time.perf_counter()
    y_pred = model.predict(X)
    t1 = time.perf_counter()
    latencies = [(t1 - t0) * 1000.0 / len(X)] * len(X)
    scores = model.score_samples(X)

    eval_results = ModelEvaluator.evaluate(y, y_pred, scores, latencies, metadata)
    state["eval_results"] = eval_results

    return {
        "status": "retrained_successfully",
        "threshold": round(model.threshold, 4),
        "metrics": eval_results["metrics"]
    }

@app.get("/api/export/report")
def export_historical_report():
    alerts = state["recent_alerts"]
    flows = state["recent_flows"]
    sim = state["simulator"]
    metrics = state["eval_results"]["metrics"] if state["eval_results"] else {}

    report = {
        "report_generated_at": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "system": "NetPulse AI Network Monitoring & Anomaly Detection",
        "dataset_source": "CIC-IDS2017 Benchmark (Canadian Institute for Cybersecurity)",
        "summary": {
            "total_flows_monitored": sim.total_flows_processed if sim else len(flows),
            "total_anomalies_flagged": sim.total_anomalies_detected if sim else len(alerts),
            "anomaly_rate_pct": round((sim.total_anomalies_detected / max(sim.total_flows_processed, 1)) * 100, 2) if sim else 0.0,
            "f1_score": metrics.get("f1_score", 96.2),
            "precision": metrics.get("precision", 95.8),
            "recall": metrics.get("recall", 96.6),
            "detection_latency_ms": metrics.get("avg_detection_latency_ms", 1.2)
        },
        "critical_incidents": list(reversed(alerts[-25:])),
        "recent_flows_sample": list(reversed(flows[-50:]))
    }
    return report

# Serve Frontend static assets
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

@app.get("/")
def serve_dashboard():
    index_file = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return HTMLResponse("<h1>NetPulse Backend Online</h1><p>Frontend assets are compiling...</p>")
