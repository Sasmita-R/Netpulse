"""
NetPulse - Context-Aware Analysis & Adaptive Behavioral Baseline Engine
Differentiates between legitimate network surges (e.g., scheduled backups,
business hour traffic) and authentic security anomalies using dynamic statistical
baselines and contextual constraints.
"""

import time
import datetime
import numpy as np
from typing import Dict, Any, Tuple, Optional

class AdaptiveBaselineEngine:
    def __init__(self, alpha: float = 0.05, sensitivity: float = 2.5):
        """
        alpha: Exponential smoothing factor (0.01 - 0.1) for adaptive EWMA.
        sensitivity: Number of standard deviations (k * sigma) for adaptive thresholding.
        """
        self.alpha = alpha
        self.sensitivity = sensitivity

        # Metric baselines: {metric_name: {'mean': val, 'var': val, 'std': val}}
        self.baselines: Dict[str, Dict[str, float]] = {
            "flow_bytes_per_sec": {"mean": 125000.0, "var": 50000.0**2, "std": 50000.0},
            "flow_packets_per_sec": {"mean": 240.0, "var": 120.0**2, "std": 120.0},
            "flow_duration_us": {"mean": 450000.0, "var": 250000.0**2, "std": 250000.0},
            "syn_flag_rate": {"mean": 0.02, "var": 0.01**2, "std": 0.01},
            "anomaly_score": {"mean": 0.32, "var": 0.08**2, "std": 0.08}
        }

        # Context-dependent profile multipliers
        self.context_profiles = {
            "BUSINESS_HOURS": {
                "bandwidth_allowance": 2.2,
                "packet_allowance": 2.0,
                "off_hour_penalty": 1.0,
                "description": "Standard business operations (08:00 - 18:00 weekdays). Higher baseline tolerance."
            },
            "EVENING": {
                "bandwidth_allowance": 1.4,
                "packet_allowance": 1.3,
                "off_hour_penalty": 1.1,
                "description": "Post-office hours (18:00 - 23:00). Moderate traffic expected."
            },
            "OFF_HOURS": {
                "bandwidth_allowance": 0.8,
                "packet_allowance": 0.7,
                "off_hour_penalty": 1.4,
                "description": "Night/Off-hours (23:00 - 08:00). High sensitivity to unexpected connection activity."
            },
            "MAINTENANCE_BACKUP": {
                "bandwidth_allowance": 4.5,
                "packet_allowance": 3.0,
                "off_hour_penalty": 0.5,
                "description": "Scheduled server sync & backup window. High bandwidth flows considered benign."
            }
        }

        self.current_context = "BUSINESS_HOURS"
        self.maintenance_mode = False
        self.history_window = []
        self.max_history = 300

    def get_current_context(self) -> str:
        if self.maintenance_mode:
            return "MAINTENANCE_BACKUP"

        # Check real-world or simulated time of day
        now = datetime.datetime.now()
        hour = now.hour
        weekday = now.weekday() < 5

        if weekday and 8 <= hour < 18:
            return "BUSINESS_HOURS"
        elif 18 <= hour < 23:
            return "EVENING"
        else:
            return "OFF_HOURS"

    def set_manual_context(self, context_name: str, maintenance: bool = False):
        if context_name in self.context_profiles:
            self.current_context = context_name
        self.maintenance_mode = maintenance

    def update_baseline(self, metric: str, value: float):
        """
        Updates EWMA mean and variance online (Welford's algorithm variant).
        """
        if metric not in self.baselines:
            self.baselines[metric] = {"mean": float(value), "var": 1.0, "std": 1.0}
            return

        b = self.baselines[metric]
        diff = value - b["mean"]
        # Update mean with exponential decay
        b["mean"] += self.alpha * diff
        # Update variance
        b["var"] = (1.0 - self.alpha) * (b["var"] + self.alpha * (diff ** 2))
        b["std"] = max(float(np.sqrt(b["var"])), 1e-4)

    def evaluate_with_context(
        self,
        raw_anomaly_score: float,
        flow_features: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Adjusts raw anomaly score using behavioral baseline and contextual modifiers.
        Returns context-aware severity, adjusted score, and behavioral classification.
        """
        context = self.get_current_context()
        profile = self.context_profiles.get(context, self.context_profiles["BUSINESS_HOURS"])

        # Update running score baseline
        self.update_baseline("anomaly_score", raw_anomaly_score)

        bytes_sec = flow_features.get("flow_bytes_per_sec", 0.0)
        packets_sec = flow_features.get("flow_packets_per_sec", 0.0)
        syn_flags = flow_features.get("syn_flag_count", 0.0)

        # Update metric baselines if flow is mostly normal
        if raw_anomaly_score < 0.65:
            self.update_baseline("flow_bytes_per_sec", bytes_sec)
            self.update_baseline("flow_packets_per_sec", packets_sec)

        score_baseline = self.baselines["anomaly_score"]
        adaptive_threshold = score_baseline["mean"] + self.sensitivity * score_baseline["std"]
        # Clamp adaptive threshold to reasonable boundaries [0.52, 0.78]
        adaptive_threshold = float(np.clip(adaptive_threshold, 0.52, 0.78))

        # Check contextual dampening vs amplification
        adjusted_score = raw_anomaly_score

        # Distinguish Benign Surge vs Attack:
        # High bandwidth with normal SYN flag and bidirectional flow during backup/business hours -> Benign surge
        bwd_pkts = flow_features.get("total_backward_packets", 1.0)
        fwd_pkts = flow_features.get("total_fwd_packets", 1.0)
        is_bidirectional = (bwd_pkts > 0 and (fwd_pkts / max(bwd_pkts, 1) < 15.0))

        behavioral_type = "NORMAL_TRAFFIC"
        context_notes = []

        if context == "MAINTENANCE_BACKUP":
            if is_bidirectional and syn_flags == 0:
                adjusted_score = max(0.2, adjusted_score * 0.55)
                behavioral_type = "BENIGN_SCHEDULED_BACKUP"
                context_notes.append("Traffic surge matches scheduled backup window parameters. Alert suppressed.")
        elif context == "BUSINESS_HOURS":
            if is_bidirectional and adjusted_score >= adaptive_threshold and adjusted_score < 0.75:
                # Moderate surge during business hours
                adjusted_score = adjusted_score * 0.85
                behavioral_type = "BENIGN_BUSINESS_PEAK"
                context_notes.append("Bandwidth surge during active business hours; classified as legitimate peak.")
        elif context == "OFF_HOURS":
            if adjusted_score > 0.50:
                adjusted_score = min(0.99, adjusted_score * profile["off_hour_penalty"])
                context_notes.append("Elevated activity during off-hours detected. Increased surveillance priority.")

        # Specific signature checks for attack patterns
        if syn_flags > 5 and bwd_pkts == 0:
            behavioral_type = "SYN_FLOOD_OR_PORTSCAN"
            adjusted_score = max(adjusted_score, 0.88)
            context_notes.append("Unidirectional SYN burst detected with zero ACK responses. Potential PortScan/DDoS.")
        elif packets_sec > 5000 and fwd_pkts > 100 and bwd_pkts <= 2:
            behavioral_type = "DISTRIBUTED_DENIAL_OF_SERVICE"
            adjusted_score = max(adjusted_score, 0.92)
            context_notes.append("Packet rate exceeds 5,000 pkts/s with extreme forward imbalance.")
        elif adjusted_score >= adaptive_threshold:
            if behavioral_type == "NORMAL_TRAFFIC":
                behavioral_type = "ANOMALOUS_DEVIATION"
                context_notes.append("Flow parameters statistically deviate from dynamic baseline.")

        # Final classification status
        is_confirmed_anomaly = (adjusted_score >= adaptive_threshold)

        # Context-adjusted severity
        if adjusted_score >= 0.82:
            severity = "CRITICAL"
        elif adjusted_score >= 0.68:
            severity = "HIGH"
        elif adjusted_score >= adaptive_threshold:
            severity = "MEDIUM"
        elif adjusted_score >= 0.45:
            severity = "LOW"
        else:
            severity = "BENIGN"

        record = {
            "timestamp": time.time(),
            "raw_score": round(raw_anomaly_score, 4),
            "adjusted_score": round(adjusted_score, 4),
            "adaptive_threshold": round(adaptive_threshold, 4),
            "is_anomaly": bool(is_confirmed_anomaly),
            "severity": severity,
            "behavioral_type": behavioral_type,
            "context": context,
            "context_notes": " ".join(context_notes) if context_notes else "Traffic conforms to expected baseline.",
            "baselines_snapshot": {
                k: round(v["mean"], 2) for k, v in self.baselines.items()
            }
        }

        self.history_window.append(record)
        if len(self.history_window) > self.max_history:
            self.history_window.pop(0)

        return record
