"""
NetPulse - Explainable AI (XAI) Engine for Network Anomaly Detection
Produces human-interpretable feature contribution breakdowns,
root-cause diagnoses, and recommended containment steps for SOC analysts.
"""

from typing import Dict, List, Any

# Standard human-friendly feature names & descriptions matching CIC-IDS2017
FEATURE_METADATA = {
    "flow_duration_us": {
        "label": "Flow Duration",
        "unit": "µs",
        "desc": "Total active duration of the bidirectional network flow."
    },
    "total_fwd_packets": {
        "label": "Forward Packets",
        "unit": "pkts",
        "desc": "Number of packets sent from source to destination."
    },
    "total_backward_packets": {
        "label": "Backward Packets",
        "unit": "pkts",
        "desc": "Number of response packets received from destination."
    },
    "total_length_fwd_packets": {
        "label": "Fwd Packet Bytes",
        "unit": "bytes",
        "desc": "Total payload bytes transmitted forward."
    },
    "total_length_bwd_packets": {
        "label": "Bwd Packet Bytes",
        "unit": "bytes",
        "desc": "Total payload bytes received in response."
    },
    "flow_bytes_per_sec": {
        "label": "Throughput (Bytes/s)",
        "unit": "B/s",
        "desc": "Bandwidth consumption rate of the flow."
    },
    "flow_packets_per_sec": {
        "label": "Packet Rate",
        "unit": "pkts/s",
        "desc": "Rate of packet transmission."
    },
    "flow_iat_mean": {
        "label": "Flow IAT Mean",
        "unit": "µs",
        "desc": "Average Inter-Arrival Time between consecutive packets."
    },
    "flow_iat_std": {
        "label": "Flow IAT StdDev",
        "unit": "µs",
        "desc": "Variability in packet arrival intervals."
    },
    "fwd_packet_length_mean": {
        "label": "Avg Fwd Packet Size",
        "unit": "bytes",
        "desc": "Average length of forward packet payloads."
    },
    "bwd_packet_length_mean": {
        "label": "Avg Bwd Packet Size",
        "unit": "bytes",
        "desc": "Average length of backward response packets."
    },
    "syn_flag_count": {
        "label": "SYN Flag Count",
        "unit": "flags",
        "desc": "Count of TCP SYN packets (connection initiation requests)."
    },
    "rst_flag_count": {
        "label": "RST Flag Count",
        "unit": "flags",
        "desc": "Count of TCP RST packets (connection reset / rejection)."
    },
    "ack_flag_count": {
        "label": "ACK Flag Count",
        "unit": "flags",
        "desc": "Count of TCP ACK packets."
    },
    "average_packet_size": {
        "label": "Avg Packet Size",
        "unit": "bytes",
        "desc": "Mean packet size over the entire flow lifetime."
    }
}

class NetPulseXAIExplainer:
    """
    Translates mathematical Isolation Forest split attributions and
    context deviations into rich, actionable Explainable AI reports.
    """

    def generate_explanation(
        self,
        flow_data: Dict[str, Any],
        raw_isolation_explanation: Dict[str, Any],
        context_evaluation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Builds a comprehensive Explainable AI dossier for a network event.
        """
        top_features = raw_isolation_explanation.get("top_contributing_features", [])
        anomaly_score = context_evaluation.get("adjusted_score", raw_isolation_explanation.get("anomaly_score", 0.0))
        severity = context_evaluation.get("severity", "LOW")
        behavioral_type = context_evaluation.get("behavioral_type", "NORMAL_TRAFFIC")
        context = context_evaluation.get("context", "BUSINESS_HOURS")

        # Format features for visual waterfall and radar display
        formatted_features = []
        for feat in top_features:
            fname = feat["feature"]
            meta = FEATURE_METADATA.get(fname, {"label": fname.replace("_", " ").title(), "unit": "", "desc": ""})

            obs = feat["observed_value"]
            baseline = feat["baseline_mean"]
            z = feat["z_score"]

            # Calculate human readable fold change
            if baseline > 1e-4:
                ratio = obs / baseline
                if ratio >= 1.0:
                    delta_text = f"+{ratio:.1f}x baseline"
                else:
                    delta_text = f"-{abs(1.0 - ratio) * 100:.0f}% below baseline"
            else:
                delta_text = f"+{obs:.1f} (spike from zero)"

            formatted_features.append({
                "feature_key": fname,
                "label": meta["label"],
                "unit": meta["unit"],
                "description": meta["desc"],
                "observed_value": self._format_num(obs),
                "baseline_mean": self._format_num(baseline),
                "z_score": round(z, 2),
                "contribution_pct": feat.get("contribution_percentage", 20.0),
                "delta_text": delta_text,
                "direction": feat.get("direction", "HIGH")
            })

        # Generate Natural Language Diagnostic Synthesis
        diagnosis, recommended_actions, attack_fingerprint = self._synthesize_diagnosis(
            flow_data, formatted_features, severity, behavioral_type, context
        )

        return {
            "flow_id": flow_data.get("flow_id", "FLOW-UNK"),
            "timestamp": flow_data.get("timestamp"),
            "anomaly_score": anomaly_score,
            "severity": severity,
            "behavioral_type": behavioral_type,
            "attack_fingerprint": attack_fingerprint,
            "natural_language_diagnosis": diagnosis,
            "context_summary": {
                "active_context": context,
                "context_notes": context_evaluation.get("context_notes", "")
            },
            "top_contributing_features": formatted_features,
            "recommended_actions": recommended_actions
        }

    def _synthesize_diagnosis(
        self,
        flow: Dict[str, Any],
        top_features: List[Dict[str, Any]],
        severity: str,
        behavioral_type: str,
        context: str
    ) -> Tuple[str, List[str], str]:
        """
        Synthesizes human-readable AI diagnostic text based on CIC-IDS2017 attack signatures.
        """
        src_ip = flow.get("src_ip", "Source")
        dst_ip = flow.get("dst_ip", "Destination")
        dst_port = flow.get("dst_port", 80)
        proto = flow.get("protocol", "TCP")

        fwd_pkts = flow.get("total_fwd_packets", 0)
        bwd_pkts = flow.get("total_backward_packets", 0)
        syn_flags = flow.get("syn_flag_count", 0)
        pkt_rate = flow.get("flow_packets_per_sec", 0)
        duration = flow.get("flow_duration_us", 0)

        # Signature matching for CIC-IDS2017 attack archetypes
        if syn_flags >= 4 and bwd_pkts == 0:
            attack_fingerprint = "PortScan / Stealth Reconnaissance"
            diagnosis = (
                f"NetPulse identified anomalous connection probing from {src_ip} towards {dst_ip}:{dst_port}. "
                f"The flow exhibited {int(syn_flags)} SYN packets with 0 reciprocal response packets (ACK/RST). "
                f"This pattern strongly matches port scanning or host discovery activity in the CIC-IDS2017 dataset."
            )
            actions = [
                f"Inspect firewall logs for rapid multi-port connection requests originating from {src_ip}.",
                f"Verify whether {src_ip} belongs to an authorized vulnerability scanner or external threat actor.",
                "Enforce rate limiting on TCP SYN packets at the border router (e.g. synflood protection).",
                f"Temporarily quarantine {src_ip} if repeated across subnet endpoints."
            ]

        elif pkt_rate > 2000 and (fwd_pkts / max(bwd_pkts, 1) > 20):
            attack_fingerprint = "Volumetric DDoS (LOIC / UDP / SYN Flood)"
            diagnosis = (
                f"Severe volumetric traffic flood detected targeting {dst_ip}:{dst_port}. "
                f"Transmission rate reached {pkt_rate:,.0f} pkts/sec with extreme unidirectional asymmetry "
                f"({int(fwd_pkts)} forward packets vs {int(bwd_pkts)} backward). "
                f"Isolation Forest isolated this flow at depth 1 due to extreme packet rate deviation."
            )
            actions = [
                f"Activate upstream DDoS mitigation / BGP Anycast scrubbing for host {dst_ip}.",
                f"Apply ingress access-list (ACL) dropping high-rate non-established traffic from {src_ip}.",
                "Monitor edge bandwidth utilization to prevent upstream interface saturation.",
                "Verify web server backend connection pools and HTTP reverse proxy status."
            ]

        elif duration > 30000000 and bwd_pkts > 0 and (flow.get("flow_bytes_per_sec", 0) < 50):
            attack_fingerprint = "Slowloris / DoS Slow HTTP Attack"
            diagnosis = (
                f"Exceedingly long flow duration ({duration/1e6:.1f} seconds) with microscopic throughput "
                f"detected against {dst_ip}:{dst_port}. This signature reflects thread exhaustion techniques "
                f"where attacker sends fragmentary HTTP headers slowly to tie up web server worker pools."
            )
            actions = [
                "Adjust HTTP server timeout thresholds (e.g., RequestReadTimeout in Apache or client_body_timeout in NGINX).",
                "Limit the maximum concurrent connections per IP address on port 80/443.",
                f"Drop lingering idle TCP sessions from source {src_ip}."
            ]

        elif fwd_pkts > 40 and dst_port in [21, 22, 3389]:
            attack_fingerprint = "Brute Force Authentication Attempt (Patator)"
            diagnosis = (
                f"Repetitive credential-oriented flow observed targeting administrative service "
                f"{dst_ip}:{dst_port} ({'SSH' if dst_port==22 else 'FTP' if dst_port==21 else 'RDP'}). "
                f"Flow characteristics match automated dictionary attacks from the CIC-IDS2017 Patator benchmark."
            )
            actions = [
                f"Enforce Fail2ban or account lockout policies on {dst_ip} for port {dst_port}.",
                f"Restrain access to {dst_port} exclusively via VPN or jump-host IP whitelist.",
                f"Review auth logs on {dst_ip} for repeated failed login attempts from {src_ip}."
            ]

        elif behavioral_type == "BENIGN_SCHEDULED_BACKUP":
            attack_fingerprint = "Legitimate Scheduled Maintenance / Backup Surge"
            diagnosis = (
                f"High bandwidth usage ({flow.get('flow_bytes_per_sec', 0)/1e6:.1f} MB/s) occurred during "
                f"the active {context} window. Flow exhibits normal balanced TCP acknowledgments and expected "
                f"payload transfers. Context-aware engine successfully suppressed false positive alert."
            )
            actions = [
                "No containment required; flow recognized as valid scheduled maintenance operation.",
                "Keep under passive observation until scheduled maintenance window concludes."
            ]

        elif severity in ["CRITICAL", "HIGH"]:
            primary_feat = top_features[0]["label"] if top_features else "Network Metric"
            primary_delta = top_features[0]["delta_text"] if top_features else "deviates"
            attack_fingerprint = "Statistical Anomaly / Suspicious Network Behavior"
            diagnosis = (
                f"NetPulse identified a high-severity behavioral deviation in communication between "
                f"{src_ip} and {dst_ip}. The primary contributor was {primary_feat} ({primary_delta}). "
                f"The flow pattern does not align with normal baseline cluster profiles."
            )
            actions = [
                f"Conduct packet capture (PCAP) inspection on traffic between {src_ip} and {dst_ip}.",
                "Check endpoint health and active processes on communicating nodes.",
                "Verify if recent network configuration or application deployments triggered this change."
            ]

        else:
            attack_fingerprint = "Benign Normal Traffic"
            diagnosis = (
                f"Network flow between {src_ip} and {dst_ip} is well within normal baseline parameters. "
                f"No anomalous feature deviations were detected by the Isolation Forest."
            )
            actions = [
                "Routine monitoring active. No action needed."
            ]

        return diagnosis, actions, attack_fingerprint

    def _format_num(self, val: float) -> str:
        if abs(val) >= 1_000_000:
            return f"{val/1_000_000:.2f}M"
        if abs(val) >= 1_000:
            return f"{val/1_000:.2f}k"
        if abs(val) < 0.01 and val != 0:
            return f"{val:.4f}"
        return f"{val:.2f}"
