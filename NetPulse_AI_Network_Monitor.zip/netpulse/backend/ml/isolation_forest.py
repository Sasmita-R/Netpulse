"""
NetPulse - Isolation Forest Anomaly Detection Engine
Implements an optimized, vectorized Isolation Forest with intrinsic Tree-Path
Feature Attribution for Explainable AI (XAI).
"""

import numpy as np
import json
import os
from typing import List, Dict, Any, Tuple, Optional

def c_factor(n: int) -> float:
    """
    Average path length of unsuccessful search in Binary Search Tree (BST).
    c(n) = 2 * (ln(n - 1) + 0.5772156649) - (2 * (n - 1) / n)
    """
    if n <= 1:
        return 1.0
    if n == 2:
        return 1.0
    euler_gamma = 0.5772156649
    return 2.0 * (np.log(n - 1) + euler_gamma) - (2.0 * (n - 1) / n)

class IsolationTreeNode:
    def __init__(
        self,
        left: Optional['IsolationTreeNode'] = None,
        right: Optional['IsolationTreeNode'] = None,
        split_feature: Optional[int] = None,
        split_value: Optional[float] = None,
        size: int = 0,
        depth: int = 0,
        is_leaf: bool = False
    ):
        self.left = left
        self.right = right
        self.split_feature = split_feature
        self.split_value = split_value
        self.size = size
        self.depth = depth
        self.is_leaf = is_leaf

    def to_dict(self) -> Dict[str, Any]:
        if self.is_leaf:
            return {"is_leaf": True, "size": self.size, "depth": self.depth}
        return {
            "is_leaf": False,
            "split_feature": self.split_feature,
            "split_value": float(self.split_value) if self.split_value is not None else 0.0,
            "size": self.size,
            "depth": self.depth,
            "left": self.left.to_dict() if self.left else None,
            "right": self.right.to_dict() if self.right else None
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'IsolationTreeNode':
        if data.get("is_leaf", False):
            return cls(size=data.get("size", 1), depth=data.get("depth", 0), is_leaf=True)
        node = cls(
            split_feature=data.get("split_feature"),
            split_value=data.get("split_value"),
            size=data.get("size", 1),
            depth=data.get("depth", 0),
            is_leaf=False
        )
        if data.get("left"):
            node.left = cls.from_dict(data["left"])
        if data.get("right"):
            node.right = cls.from_dict(data["right"])
        return node

class IsolationTree:
    def __init__(self, max_depth: int):
        self.max_depth = max_depth
        self.root: Optional[IsolationTreeNode] = None

    def fit(self, X: np.ndarray, current_depth: int = 0) -> IsolationTreeNode:
        n_samples, n_features = X.shape

        if current_depth >= self.max_depth or n_samples <= 1:
            return IsolationTreeNode(size=n_samples, depth=current_depth, is_leaf=True)

        # Randomly choose a feature
        feature_idx = np.random.randint(0, n_features)
        feat_min = np.min(X[:, feature_idx])
        feat_max = np.max(X[:, feature_idx])

        if np.isclose(feat_min, feat_max):
            return IsolationTreeNode(size=n_samples, depth=current_depth, is_leaf=True)

        # Random split point between min and max
        split_val = np.random.uniform(feat_min, feat_max)

        left_mask = X[:, feature_idx] < split_val
        right_mask = ~left_mask

        if np.sum(left_mask) == 0 or np.sum(right_mask) == 0:
            return IsolationTreeNode(size=n_samples, depth=current_depth, is_leaf=True)

        left_node = self.fit(X[left_mask], current_depth + 1)
        right_node = self.fit(X[right_mask], current_depth + 1)

        return IsolationTreeNode(
            left=left_node,
            right=right_node,
            split_feature=feature_idx,
            split_value=split_val,
            size=n_samples,
            depth=current_depth,
            is_leaf=False
        )

    def path_length(self, x: np.ndarray) -> Tuple[float, List[Tuple[int, float]]]:
        """
        Traverse the tree for a single point x.
        Returns:
            path_len: Total estimated path length including leaf adjustment.
            features_visited: List of (feature_index, depth_at_split).
        """
        curr = self.root
        depth = 0
        visited = []

        while curr and not curr.is_leaf:
            visited.append((curr.split_feature, depth))
            if x[curr.split_feature] < curr.split_value:
                curr = curr.left
            else:
                curr = curr.right
            depth += 1

        leaf_size = curr.size if curr else 1
        leaf_adj = c_factor(leaf_size) if leaf_size > 1 else 0.0
        return float(depth + leaf_adj), visited

class NetPulseIsolationForest:
    """
    Robust Isolation Forest designed for Network Anomaly Detection.
    Includes built-in Explainable AI (XAI) feature attribution.
    """
    def __init__(
        self,
        n_estimators: int = 100,
        max_samples: int = 256,
        contamination: float = 0.05,
        random_state: int = 42
    ):
        self.n_estimators = n_estimators
        self.max_samples = max_samples
        self.contamination = contamination
        self.random_state = random_state
        self.trees: List[IsolationTree] = []
        self.threshold: float = 0.55
        self.feature_names: List[str] = []
        self.feature_means: np.ndarray = np.array([])
        self.feature_stds: np.ndarray = np.array([])

    def fit(self, X: np.ndarray, feature_names: Optional[List[str]] = None) -> 'NetPulseIsolationForest':
        if self.random_state is not None:
            np.random.seed(self.random_state)

        n_samples, n_features = X.shape
        self.feature_names = feature_names or [f"feature_{i}" for i in range(n_features)]
        self.feature_means = np.mean(X, axis=0)
        self.feature_stds = np.std(X, axis=0) + 1e-7

        subsample_size = min(self.max_samples, n_samples)
        max_depth = int(np.ceil(np.log2(max(subsample_size, 2))))

        self.trees = []
        for _ in range(self.n_estimators):
            idx = np.random.choice(n_samples, size=subsample_size, replace=False)
            tree = IsolationTree(max_depth=max_depth)
            tree.root = tree.fit(X[idx], current_depth=0)
            self.trees.append(tree)

        # Calibrate decision threshold based on contamination
        scores = self.score_samples(X)
        self.threshold = float(np.percentile(scores, 100 * (1.0 - self.contamination)))
        # Safety bound
        self.threshold = max(0.48, min(0.85, self.threshold))
        return self

    def calibrate_with_labels(self, X: np.ndarray, y: np.ndarray):
        """
        Calibrates threshold to maximize F1-score when ground-truth labels are available.
        """
        scores = self.score_samples(X)
        best_f1 = 0.0
        best_t = self.threshold

        for t in np.linspace(0.40, 0.75, 71):
            preds = (scores >= t).astype(int)
            tp = np.sum((y == 1) & (preds == 1))
            fp = np.sum((y == 0) & (preds == 1))
            fn = np.sum((y == 1) & (preds == 0))
            prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2 * (prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0
            if f1 > best_f1:
                best_f1 = f1
                best_t = float(t)

        self.threshold = best_t
        return self.threshold, best_f1

    def score_sample(self, x: np.ndarray) -> Tuple[float, Dict[int, float]]:
        """
        Compute anomaly score for single sample and feature attribution.
        Higher score = more anomalous (range approx 0.0 to 1.0).
        Score > threshold implies anomalous.
        """
        total_path_length = 0.0
        feature_early_split_counts: Dict[int, float] = {i: 0.0 for i in range(len(x))}

        for tree in self.trees:
            path_len, visited = tree.path_length(x)
            total_path_length += path_len

            # In Isolation Trees, features that split earliest (lowest depth)
            # are the ones isolating the point from normal clusters.
            # We weight contribution inversely by split depth: 1.0 / (depth + 1)
            for feat_idx, depth in visited:
                if feat_idx is not None and feat_idx in feature_early_split_counts:
                    feature_early_split_counts[feat_idx] += 1.0 / (depth + 1.0)

        avg_path = total_path_length / len(self.trees)
        c_psi = c_factor(self.max_samples)

        # Standard Liu et al. formula: s = 2 ^ (- avg_path / c_psi)
        anomaly_score = float(2.0 ** (- avg_path / c_psi))

        return anomaly_score, feature_early_split_counts

    def score_samples(self, X: np.ndarray) -> np.ndarray:
        scores = []
        for i in range(len(X)):
            score, _ = self.score_sample(X[i])
            scores.append(score)
        return np.array(scores)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Returns 1 for anomaly, 0 for normal (benign).
        """
        scores = self.score_samples(X)
        return (scores >= self.threshold).astype(int)

    def explain(self, x: np.ndarray, top_k: int = 5) -> Dict[str, Any]:
        """
        Explain why sample x is anomalous or benign.
        Returns top contributing features with attribution weights,
        z-scores, and directional impact.
        """
        score, feat_weights = self.score_sample(x)
        is_anomaly = score >= self.threshold

        total_weight = sum(feat_weights.values()) + 1e-9
        normalized_weights = {k: v / total_weight for k, v in feat_weights.items()}

        # Combine with statistical deviation (Z-score vs baseline training set)
        z_scores = (x - self.feature_means) / self.feature_stds

        explanations = []
        for i, name in enumerate(self.feature_names):
            tree_weight = normalized_weights.get(i, 0.0)
            z = float(z_scores[i])
            val = float(x[i])
            baseline_val = float(self.feature_means[i])

            # Composite importance score combining isolation split speed and deviation
            composite_importance = tree_weight * (1.0 + min(abs(z), 10.0) / 2.0)

            explanations.append({
                "feature": name,
                "feature_index": i,
                "importance": float(composite_importance),
                "tree_split_weight": float(tree_weight),
                "observed_value": val,
                "baseline_mean": baseline_val,
                "z_score": z,
                "direction": "HIGH" if z > 0 else "LOW"
            })

        # Sort by importance descending
        explanations.sort(key=lambda item: item["importance"], reverse=True)

        # Normalize importance of top features to percentages
        top_explanations = explanations[:top_k]
        top_sum = sum(e["importance"] for e in top_explanations) + 1e-9
        for e in top_explanations:
            e["contribution_percentage"] = round((e["importance"] / top_sum) * 100, 1)

        # Determine severity
        if score >= 0.80:
            severity = "CRITICAL"
        elif score >= 0.65:
            severity = "HIGH"
        elif score >= self.threshold:
            severity = "MEDIUM"
        else:
            severity = "NORMAL"

        return {
            "anomaly_score": round(score, 4),
            "is_anomaly": bool(is_anomaly),
            "severity": severity,
            "threshold": round(self.threshold, 4),
            "top_contributing_features": top_explanations,
            "all_features_summary": explanations
        }

    def save(self, filepath: str):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        data = {
            "n_estimators": self.n_estimators,
            "max_samples": self.max_samples,
            "contamination": self.contamination,
            "threshold": self.threshold,
            "feature_names": self.feature_names,
            "feature_means": self.feature_means.tolist(),
            "feature_stds": self.feature_stds.tolist(),
            "trees": [t.root.to_dict() if t.root else None for t in self.trees]
        }
        with open(filepath, "w") as f:
            json.dump(data, f)

    @classmethod
    def load(cls, filepath: str) -> 'NetPulseIsolationForest':
        with open(filepath, "r") as f:
            data = json.load(f)

        forest = cls(
            n_estimators=data["n_estimators"],
            max_samples=data["max_samples"],
            contamination=data["contamination"]
        )
        forest.threshold = data["threshold"]
        forest.feature_names = data["feature_names"]
        forest.feature_means = np.array(data["feature_means"])
        forest.feature_stds = np.array(data["feature_stds"])

        forest.trees = []
        for tree_dict in data["trees"]:
            t = IsolationTree(max_depth=int(np.ceil(np.log2(data["max_samples"]))))
            if tree_dict:
                t.root = IsolationTreeNode.from_dict(tree_dict)
            forest.trees.append(t)

        return forest
