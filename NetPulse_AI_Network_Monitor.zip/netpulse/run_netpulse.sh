#!/usr/bin/env bash
# ==============================================================================
# NetPulse - AI Network Monitoring & Anomaly Detection System Launcher
# ==============================================================================

echo "==============================================================================="
echo "               NETPULSE: AI NETWORK MONITORING SYSTEM"
echo "        Isolation Forest Anomaly Detection with Explainable AI (XAI)"
echo "                Dataset: CIC-IDS2017 (Canadian Cybersec)"
echo "==============================================================================="
echo ""

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 could not be found. Please install Python 3.9+."
    exit 1
fi

echo "[1/3] Installing dependencies..."
python3 -m pip install -r requirements.txt --quiet

echo "[2/3] Opening browser at http://localhost:8000..."
if command -v xdg-open &> /dev/null; then
    xdg-open "http://localhost:8000" &
elif command -v open &> /dev/null; then
    open "http://localhost:8000" &
fi

echo "[3/3] Starting NetPulse Server on http://127.0.0.1:8000 (Press Ctrl+C to terminate)..."
python3 -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
