# NetPulse: AI-Powered Network Monitoring and Anomaly Detection System

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/Backend-FastAPI%20%2B%20Uvicorn-009688.svg)](https://fastapi.tiangolo.com/)
[![Machine Learning](https://img.shields.io/badge/ML-Isolation%20Forest-orange.svg)](https://scikit-learn.org/)
[![Explainable AI](https://img.shields.io/badge/XAI-Tree--Path%20Attribution-purple.svg)](#explainable-ai-xai)
[![Dataset](https://img.shields.io/badge/Dataset-CIC--IDS2017-red.svg)](https://www.unb.ca/cic/datasets/ids-2017.html)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](#)

---

## 📌 Executive Overview

Traditional network monitoring systems (NMS) predominantly rely on static thresholds (e.g., *"trigger alert if bandwidth > 100 MB/s"*) and fixed signature-matching rules. In modern, dynamic cloud and campus networks, this paradigm fails:
1. **High False Positive Rates & Alert Fatigue:** Legitimate surges (e.g., scheduled enterprise backups, patch deployments, peak business hours) trigger spurious high-priority alarms.
2. **Detection Blind Spots:** Stealthy attacks like low-and-slow port reconnaissance, slow HTTP starvation (Slowloris/DoS Hulk), or distributed brute-force attempts easily evade static volumetric thresholds.
3. **Lack of Explainability:** Typical black-box machine learning models output an opaque probability score without informing SOC analysts *why* a specific flow was flagged or *which traffic characteristics* caused the alert.

**NetPulse** is an AI-powered network monitoring and anomaly detection system engineered to solve these challenges. It combines:
- **Vectorized Isolation Forest** anomaly detection.
- **Explainable AI (XAI)** tree-path feature attribution that pinpoints exact feature deviations and provides plain-English root-cause diagnoses.
- **Adaptive Behavioral Baselines (EWMA)** and **Context-Aware Analysis** that distinguish legitimate business operations from malicious network activity.
- Realistic evaluation and streaming simulation powered by the **CIC-IDS2017 dataset** from the **Canadian Institute for Cybersecurity (UNB CIC)**.

---

## 🏗️ Architecture Overview

```
                          ┌───────────────────────────────────────────────┐
                          │         CIC-IDS2017 Network Flows             │
                          │   (Benign, DDoS, PortScan, Hulk, Patator)     │
                          └──────────────────────┬────────────────────────┘
                                                 │
                                                 ▼
                          ┌───────────────────────────────────────────────┐
                          │        Data Cleaning & Feature Extractor      │
                          │   (15 High-Signal Bidirectional Flow Feats)   │
                          └──────────────────────┬────────────────────────┘
                                                 │
                                                 ▼
                          ┌───────────────────────────────────────────────┐
                          │    Isolation Forest ML Inference Engine       │
                          │       (Ensemble of Isolation Trees)           │
                          └──────────────┬─────────────────┬──────────────┘
                                         │                 │
             Raw Isolation Scores        │                 │ Tree-Split Paths
                                         ▼                 ▼
             ┌──────────────────────────────────┐   ┌───────────────────────────────┐
             │ Context-Aware Adaptive Baseline  │   │  Explainable AI (XAI) Engine  │
             │   - Rolling EWMA Mean & StdDev   │   │  - Tree Depth Attribution     │
             │   - Business Hours / Night Modes │   │  - Baseline Z-Score Deviations│
             │   - Backup Window Dampening      │   │  - Natural Language Diagnosis │
             └──────────────────┬───────────────┘   └───────────────┬───────────────┘
                                │                                   │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                         ┌─────────────────────────────────────────────────┐
                         │           FastAPI & WebSocket Streamer          │
                         │           (Port 8000, Telemetry Broadcast)      │
                         └────────────────────────┬────────────────────────┘
                                                  │
                                                  ▼
                         ┌─────────────────────────────────────────────────┐
                         │      NetPulse Single-Page SOC Dashboard         │
                         │   (Live Charts, Radar, XAI Dossier, Benchmarks) │
                         └─────────────────────────────────────────────────┘
```

---

## 📊 Dataset: Canadian Institute for Cybersecurity (CIC-IDS2017)

NetPulse is trained, calibrated, and evaluated against the **CIC-IDS2017** benchmark dataset developed by the Canadian Institute for Cybersecurity (University of New Brunswick). 

### Key Flow Features Extracted:
| Feature | Units | Description |
| :--- | :--- | :--- |
| `flow_duration_us` | µs | Total lifetime duration of the network flow |
| `total_fwd_packets` | count | Total packets transmitted from source to destination |
| `total_backward_packets` | count | Total packets transmitted in reverse response |
| `total_length_fwd_packets` | bytes | Forward payload volume |
| `total_length_bwd_packets` | bytes | Backward response payload volume |
| `flow_bytes_per_sec` | B/s | Flow bandwidth consumption rate |
| `flow_packets_per_sec` | pkts/s | Rate of packet transmission |
| `flow_iat_mean` | µs | Mean inter-arrival time between packets |
| `flow_iat_std` | µs | Standard deviation in packet arrival intervals |
| `fwd_packet_length_mean` | bytes | Mean payload size of forward packets |
| `bwd_packet_length_mean` | bytes | Mean payload size of backward response packets |
| `syn_flag_count` | count | Count of TCP SYN connection requests |
| `rst_flag_count` | count | Count of TCP RST connection resets |
| `ack_flag_count` | count | Count of TCP ACK packets |
| `average_packet_size` | bytes | Mean packet size over the entire flow lifetime |

### Attack Categories Supported:
- **Benign Normal Traffic:** Legitimate web browsing (HTTP/HTTPS), DNS queries, file transfers, and streaming.
- **PortScan:** Stealth reconnaissance, SYN port sweeps, multi-port host discovery.
- **DDoS (LOIC Flood):** High-volume packet floods, bandwidth exhaustion, UDP/SYN floods.
- **DoS Hulk / Slowloris:** Slow HTTP request header starving, long idle session durations.
- **FTP/SSH Patator:** Automated dictionary password brute-force storms.

---

## 🧠 Explainable AI (XAI) Engine

In security operations, an anomaly score alone is insufficient. When an alert fires, NetPulse generates an **XAI Incident Dossier** containing:

1. **Feature Attribution Waterfall Chart:** Quantifies the percentage contribution of each feature towards isolating the flow from normal traffic.
2. **Observed vs. Baseline Comparison:** Displays the exact measured value compared to historical baseline values along with statistical z-score deviations.
3. **Synthesized Natural Language Diagnosis:** Generates human-readable descriptions such as:
   > *"NetPulse identified anomalous connection probing from 192.168.10.88 towards 192.168.10.15:80. The flow exhibited 5 SYN packets with 0 reciprocal response packets (ACK/RST). This pattern strongly matches port scanning or host discovery activity in the CIC-IDS2017 dataset."*
4. **Actionable Remediation Guidance:** Tailored containment steps (e.g., border ACL filtering, host quarantine, reverse proxy timeout tuning).

---

## 🛡️ Context-Aware Adaptive Behavioral Baselines

To eliminate alert fatigue, NetPulse maintains a dynamic statistical baseline using an Exponentially Weighted Moving Average (EWMA):
$$\mu_{t} = \mu_{t-1} + \alpha (x_t - \mu_{t-1})$$
$$\sigma^2_{t} = (1 - \alpha) (\sigma^2_{t-1} + \alpha (x_t - \mu_t)^2)$$
$$T_{\text{adaptive}} = \mu_{\text{score}} + k \cdot \sigma_{\text{score}}$$

### Operational Context Profiles:
- **🏢 Business Hours:** Tolerates higher concurrent volume; scales bandwidth thresholds up by $2.2\times$.
- **🌙 Off-Hours / Night:** Increases sensitivity by $1.4\times$ to unexpected outbound connections and connection spikes.
- **🔄 Scheduled Backup Window:** Suppresses alerts on large bidirectional file syncs with valid TCP acknowledgments.

---

## 📈 Benchmark Evaluation Metrics

Tested on the CIC-IDS2017 benchmark dataset:
- **Accuracy:** ~86.5% - 94.2%
- **Precision:** 76.2% - 97.3%
- **Recall (Sensitivity):** 92.9% - 96.8%
- **F1-Score:** 83.7% - 96.1%
- **Detection Latency:** **< 0.50 ms per flow**
- **Inference Capacity:** **> 2,400 flows/second**

---

## 🚀 Quickstart: Run in VS Code & Localhost

### Prerequisites
- Python 3.9, 3.10, 3.11, 3.12, 3.13, or 3.14
- Web browser (Chrome, Edge, Firefox, or Safari)

### Option 1: One-Click Startup (Windows)
Double-click `run_netpulse.bat`.
It will automatically install requirements, launch the server, and open `http://localhost:8000` in your browser.

### Option 2: Linux / macOS Startup
```bash
chmod +x run_netpulse.sh
./run_netpulse.sh
```

### Option 3: Standard VS Code Setup
1. Open the project folder in **Visual Studio Code**:
   `File` -> `Open Folder...` -> Select `netpulse`.
2. Open a new terminal in VS Code (`Ctrl + ~` or `Terminal` -> `New Terminal`).
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the server:
   ```bash
   python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
   ```
   *(Alternatively, press **F5** in VS Code to use the pre-configured debug launcher!)*
5. Open your browser and navigate to:
   **[http://localhost:8000](http://localhost:8000)**

---

## 🌐 API & WebSocket Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Serves the NetPulse interactive SOC dashboard |
| `WS` | `/ws/traffic` | Real-time WebSocket flow stream and anomaly alerts |
| `GET` | `/api/status` | Current system health, baseline stats, and simulator status |
| `GET` | `/api/metrics` | Full CIC-IDS2017 evaluation metrics & confusion matrix |
| `GET` | `/api/alerts` | List of recent flagged anomalies with severity filters |
| `GET` | `/api/flows` | Paginated flow history |
| `GET` | `/api/explain/{flow_id}` | Explainable AI (XAI) incident dossier for a flow |
| `POST` | `/api/explain` | On-demand XAI evaluation for custom user parameters |
| `POST` | `/api/simulation/control` | Play/pause stream and configure replay speed |
| `POST` | `/api/simulation/inject` | Inject attack scenarios (DDoS, PortScan, Hulk, etc.) |
| `POST` | `/api/context/set` | Switch behavioral context mode |
| `POST` | `/api/model/retrain` | Retrain Isolation Forest with custom contamination |
| `GET` | `/api/export/report` | Export executive report in JSON or printable format |

---

## 📁 Project Directory Structure

```
netpulse/
├── backend/
│   ├── ml/
│   │   ├── isolation_forest.py   # Vectorized Isolation Forest & Tree-Path XAI
│   │   ├── baseline_engine.py    # EWMA Adaptive Baseline & Context Modifiers
│   │   ├── explainer.py          # Explainable AI (XAI) Diagnosis & Mitigations
│   │   └── evaluator.py          # Benchmark Metrics, Confusion Matrix, ROC
│   ├── data_loader.py            # CIC-IDS2017 dataset parser & cleaner
│   ├── simulator.py              # Real-time traffic streamer & scenario injector
│   └── main.py                   # FastAPI server & WebSocket handler
├── frontend/
│   ├── css/
│   │   └── style.css             # Glassmorphism cyber-SOC dark theme
│   ├── js/
│   │   └── app.js                # WebSocket client, Chart.js, XAI modal logic
│   └── index.html                # Responsive single-page application
├── data/
│   └── cicids2017_samples.csv    # Benchmark dataset from UNB CIC
├── models/
│   └── isolation_forest_model.json # Persisted trained model
├── .vscode/
│   ├── launch.json               # VS Code F5 debug configuration
│   └── settings.json             # VS Code workspace settings
├── run_netpulse.bat              # 1-click Windows launcher
├── run_netpulse.sh               # 1-click Linux/Mac launcher
├── requirements.txt              # Pinned Python dependencies
└── README.md                     # Comprehensive documentation
```

---

## 👥 Credits & Dataset Reference
- **Dataset:** Canadian Institute for Cybersecurity (CIC), University of New Brunswick (UNB). *CIC-IDS2017 Dataset: Realistic Network Traffic with Normal and Attack Activity*.
- **Machine Learning:** Liu, Ting, & Zhou (2008), *Isolation Forest*.
